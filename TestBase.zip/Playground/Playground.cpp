#include <iostream>
#include<GL/glut.h>

GLfloat TranslateV = 0;
GLfloat TransalteH = 0;

void init() {
    glClearColor(1.0, 0.0, 1.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, 100.0, 0.0, 100.0);

}

void GL_display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(1.0, 1.0, 1.0);
    glPushMatrix();

    glRecti(-2 + TransalteH, -2 + TranslateV, 3 + TransalteH, 3 + TranslateV);
    glPopMatrix();

    glutSwapBuffers();
}

void GL_reshape(GLsizei w, GLsizei h) {
    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10, 10, -10, 10);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

}

void GL_kryboard(unsigned char key, int x, int y) {
    switch (key) {
    case 'w':
        TranslateV += 1;
        glutPostRedisplay();
        break;

    case 'W':
        TranslateV -= 1;
        glutPostRedisplay();
        break;

    case 'd':
        TransalteH += 1;
        glutPostRedisplay();
        break;

    case 'a':
        TransalteH -= 1;
        glutPostRedisplay();
        break;

    case 27:
        exit(0);
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutCreateWindow("User Controlled Transformations");
    init();
    glutDisplayFunc(GL_display);
    glutReshapeFunc(GL_reshape);
    glutKeyboardFunc(GL_kryboard);
    glutMainLoop();
}
